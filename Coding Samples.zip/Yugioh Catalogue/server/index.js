// Dependencies, etc -------------------------------------------------------------------------
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const {Sequelize} = require('sequelize');

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

//---------------------------------------------------------------------------------------------
// Connect to Database
const sequelize = new Sequelize('yugioh', 'wustl_inst', 'wustl_pass', {
  host: 'localhost',
  dialect: 'mariadb',
});


//---------------------------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------------------------

// Gets all the sets listed in the set database
app.get('/api/getSets', async (req,res)=> {
	const queryTxt = "select * from sets";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send(results);
});


// Gets all the cards from the given set
app.post('/api/getCards', async (req,res)=> {
	console.log(req.body.setCode);
	const setCode = req.body.setCode;
	const queryTxt = "select cardCode, cardName, picURL from cards where setCode='" + setCode + "'";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send(results);
});


// Searched for any matches to the given parameter in either sets or cards
app.post('/api/search', async (req,res)=> {
	const searchIn = req.body.searchParam;
	console.log(searchIn);

	// Grab sets that have the search parameter as part of their code or their name
	const queryTxt1 = "select * from sets where code like '%" + searchIn + "%' or setName like '%" + searchIn + "%'";
	console.log(queryTxt1);
	const [results1, meta1] = await sequelize.query(queryTxt1);

	// Grab cards that have the search paramter as part of their code or their name
	const queryTxt2 = "select * from cards where cardCode like '%" + searchIn + "%' or cardName like '%" + searchIn + "%' order by setCode asc";
	console.log(queryTxt2);
	const [results2, meta2] = await sequelize.query(queryTxt2);

	// Just some checking
	console.log(results1.length + " " + results2.length);
	if (results1.length > 0){
		console.log('there are sets');
	}
	if (results2.length > 0){
		console.log('there are cards');
	}

	// Send back both results
	res.send([results1,results2])
});


// Grab the given user's personal collection
app.post('/api/getCollection', async (req,res)=> {
	console.log(req.body.userName);
	const userName = req.body.userName;
	const queryTxt = "select cardCode, cardName, quality, quantity from collections where user='" + userName + "'";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send(results);
});

// Grab the given user's wishlist
app.post('/api/getWishlist', async (req,res)=> {
	console.log(req.body.userName);
	const userName = req.body.userName;
	const queryTxt = "select cardCode, cardName from wishlists where user='" + userName + "'";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send(results);
});


// Attempt to log user in with given name and password
app.post('/api/login', async (req,res)=> {
	const userIn = req.body.userInput;
	const passIn = req.body.passInput;
	//console.log(userIn);
	//console.log(passIn);

	// Give it a shot
	const queryTxt = "select username, password from users where username='" + userIn + "' and password='" + passIn + "'";
	console.log(queryTxt);
	const [results, meta] = await sequelize.query(queryTxt);
	console.log(results.length);

	// If there's a matching user, tell client to log them in
	if (results.length > 0){
		res.send(true);
		console.log('true');
	}
	// If there's not, tell client it didn't work out
	else {
		res.send(false);
		console.log('false');
	}
});


// Attempt to regiser a user with given name and password
app.post('/api/register', async (req,res,next)=> {
	const userIn = req.body.userInput;
	const passIn = req.body.passInput;
	//console.log(userIn);
	//console.log(passIn);

	// Provided the given fields aren't the default (empty), try to add them to the database
	if (userIn != '' || passIn !='') {
		const queryTxt = "insert into users (username, password) values('"+ userIn +"', '"+ passIn +"')";
		console.log(queryTxt);
		await sequelize.query(queryTxt)
		.then(data => res.send(true)) // if it works out, let the client know 
		.catch(err => res.send(false)); // if it doesn't work out, let the client know
	}
});


// Add the given card(s) to the user's personal collection
app.post('/api/add2Coll', async (req,res)=> {
	const userName = req.body.user;
	const code = req.body.code;
	const name = req.body.name;
	const quality = req.body.quality;
	const quantity = req.body.quantity;

	// Add the card, but if it's already there, just increase the number by the quantity given
	const queryTxt = `insert into collections (user, cardCode, cardName, quality, quantity) 
										values('`+ userName +`', '`+ code +`', '`+ name +`', '`+ quality +`', `+ quantity +`)
										on duplicate key update quantity=quantity+` + quantity;
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send('success');
});


// Change an entry in the collection
app.post('/api/change2Coll', async (req,res)=> {
	const userName = req.body.user;
	const code = req.body.code;
	const name = req.body.name;
	const currQuality = req.body.currQuality;
	const currQuantity = req.body.currQuantity;
	const form = req.body.form;
	const value = req.body.value;

	let queryTxt = '';

	//if we're updating quality
	if (form === 'quality'){
		console.log('quality1');
		queryTxt = `update collections set quality='`+ value +`' 
								where quality='` + currQuality + `' and user='` + userName + `' and cardCode='` + code + `'`;
	}
	//if we're updating quantity
	else {
		console.log('quantity');
		queryTxt = `update collections set quantity='`+ value +`' 
								where quality='` + currQuality + `' and user='` + userName + `' and cardCode='` + code  + `'`;
	}

	console.log(queryTxt);
	await sequelize.query(queryTxt)
	.then(data => res.send('noReplace'))
	// if the new quality co-incides with an old quality...
	.catch(async err => {
			console.log('quality2');
			console.log(err);
			// add the old number to the new
			const queryTxt2 = `update collections set quantity=quantity+'`+ currQuantity +`' 
												where quality='` + value + `' and user='` + userName + `' and cardCode='` + code  + `'`;
			// delete the old entry
			const queryTxt3 = `delete from collections 
											where quality='` + currQuality + `' and user='` + userName + `' and cardCode='` + code  + `'`;
			await sequelize.query(queryTxt2);
			await sequelize.query(queryTxt3);
			res.send('Replace'); //let client know we replaced something (for bookkeeping)
			});
});


// Delete an entry from the user's personal collection
app.post('/api/del2Coll', async (req,res)=> {
	const userName = req.body.user;
	const code = req.body.code;
	const quality = req.body.quality;

	const queryTxt = "delete from collections where user='" + userName + "' and cardCode='" + code + "' and quality='" + quality  + "'";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send('success');
});


// Adds a given card to the user's wishlist
app.post('/api/add2Wish', async (req,res,next)=> {
	const userName = req.body.user;
	const code = req.body.code;
	const name = req.body.name;

	const queryTxt = `insert into wishlists (user, cardCode, cardName) values('`+ userName +`', '`+ code +`', '`+ name +`')`;
	console.log(queryTxt);
		await sequelize.query(queryTxt)
		// if it works, let the client know
		.then(data => res.send(true))
		// if there's already a card in the wishlist, let the client know
		.catch(err => res.send(false));
});


// Delete a card from the user's wishlist
app.post('/api/del2Wish', async (req,res)=> {
	const userName = req.body.user;
	const code = req.body.code;

	const queryTxt = "delete from wishlists where user='" + userName + "' and cardCode='" + code + "'";
	const [results, meta] = await sequelize.query(queryTxt);
	//console.log(results);
	res.send('success');
});

// Listen on a port other than 3000 (the client port)
app.listen(3001, () => {
	console.log('running on port 3001');
})