//---------------------------------------------------------------------------------------------
// Dependencies, etc
//---------------------------------------------------------------------------------------------
import React, {useState, useEffect} from "react";
import Axios from 'axios';
import './App.css';

const App = () => {


//---------------------------------------------------------------------------------------------
// State Variables
//---------------------------------------------------------------------------------------------
  const [searchIn, setSearchIn] = useState('');
  const [userIn, setUserIn] = useState('');
  const [passIn, setPassIn] = useState('');

  const [qualityIn, setQualityIn] = useState('Damaged');
  const [quantityIn, setQuantityIn] = useState(1);

  const [user, setUser] = useState('');
  const [logRegContent, setLogReg] = useState();
  const [isLoggedin, setLogged] = useState(false);

  const [setList, makeSets] = useState([]);
  const [mainContent, setMain] = useState(<p>No main content yet</p>);


//---------------------------------------------------------------------------------------------
// Effects to monitor changes in state and act accordingly
//---------------------------------------------------------------------------------------------

  // Get sets on loadup
  useEffect(()=> {
    Axios.get('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/getSets').then((response) => {
      makeSets(response.data);
      });
  }, []);


  // Book-keeping
  useEffect(()=> {
    console.log("qualityIn: " + qualityIn);
  }, [qualityIn]);

  useEffect(()=> {
    console.log("quantityIn: " + quantityIn);
  }, [quantityIn]);

  // Redo sets anytime setList is changed
  useEffect(()=> {
    showSets();
  }, [setList]);


  // Changes the display to allow for logging-in/registering and logging-out
  useEffect(()=> {
    //if logged in, give them ability to log out
    if (isLoggedin){
      const logContent = 
        <div id='logReg'>
          <button onClick={()=>{tryLogout()}}>Logout</button>
        </div>;
      setLogReg(logContent);
    }
    else{
      // if not logged in, give them ability to register or log in
      const logContent = 
        <div id='logReg'>
          <input type='text' name="uNameIn" placeholder="Username" onChange={(e) => {setUserIn(e.target.value);}}/>
          <input type='text' name="passIn" placeholder="Password" onChange={(e) => {setPassIn(e.target.value);}}/>
          <button onClick={()=>{tryLogin()}}>Login</button>
          <button onClick={()=>{tryRegister()}}>Register</button>
        </div>;
      setLogReg(logContent);
    }
  }, [isLoggedin, userIn, passIn]);


//---------------------------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------------------------

  // Display all sets
  const showSets = () => {
    console.log("---showSets");

    const sets = setList.map((set) =>
      <li onClick={()=>{showSetCards(set.code)}}>{set.setName}</li> );
    const setContent = 
      <>
      <h1>Sets</h1>
      <ul>{sets}</ul>
      </>

    setMain(setContent);
  }


  // Display cards for the given set
  const showSetCards = (setCode) => {
    console.log("Display cards from " + setCode);
    // get the cards in the set
    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/getCards', 
      {setCode: setCode}).then((response) => {
        console.log(response.data);
        const cards = response.data.map((card) =>
          <li onClick={()=>{showCardInfo(card)}}>{card.cardCode}: {card.cardName}</li> );
        const setContent = 
          <>
          <h1>Cards in {setCode}</h1>
          <ul>{cards}</ul>
          </>

        //console.log(setContent);
        setMain(setContent);
    });
  }


  // Displays info for the given card
  const showCardInfo = (card) => {
    console.log("---showCardInfo " + card.cardCode);
    console.log(isLoggedin);
    setQuantityIn('Damaged');
    setQuantityIn(1);
    if (isLoggedin){
      console.log("logged in");
      const cardContent = 
        <>
        <h1>{card.cardCode}: {card.carName}</h1>
        <img src={card.picURL} alt="CardPic" /> <br></br>

        <label>How many?  </label>
          <select onChange={(e) => {setQuantityIn(e.target.value);}}>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
          </select>

          <label>   What quality?  </label>
          <select onChange={(e) => {setQualityIn(e.target.value);}}>
            <option>Damaged</option>
            <option>Moderate</option>
            <option>Fair</option>
            <option>Mint</option>
          </select>

        <button onClick={()=>{add2Collection(card)}}>Add to Collection</button>
        <button onClick={()=>{add2Wishlist(card)}}>Add to Wishlist</button>
        </>;
        setMain(cardContent);
    }
    //no buttons to add to collection/wishlist if not logged in
    else {
      const cardContent = 
        <>
        <h1>{card.cardCode}: {card.carName}</h1>
        <img src={card.picURL} alt="CardPic" />
        </>;
        setMain(cardContent);
    }
  } 


  // Display's the given user's personal collection
  const showColl = () => {
    console.log("---showColl");
    // if not logged in, just tell them they need to to see the personal collection
    if (!isLoggedin){
      const collContent = 
        <>
        <h1>Personal Collection</h1>
        <p> Please log in to view your personal collection. </p>
        </>;

        setMain(collContent);
    } 
    // otherwise, grab the collection from the server
    //    changes in quality or quantity are immediately given to database
    else{
      console.log("Showing collection for " + user);
      Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/getCollection', 
        {userName: user}).then((response) => {
          console.log(response.data);
          // display the collection as a table
          const cards = response.data.map((card) =>
            <tr>
              <td>{card.cardCode}</td>
              <td>{card.cardName}</td> 
              <td>
                <select defaultValue={card.quality} selected onChange={(e) => {changeColl(e.target.value,'quality',card);}}>
                  <option>Damaged</option>
                  <option>Moderate</option>
                  <option>Fair</option>
                  <option>Mint</option>
                </select>
              </td> 
              <td><input className="quantNum" type="number" min="1" maxLength="5" defaultValue={card.quantity} onChange={(e) => {changeColl(e.target.value,'quantity',card);}}/></td>
              <td><button onClick={()=>{del2Collection(card)}}>Delete</button></td>
            </tr>);
          const collContent = 
            <>
            <h1>Personal Collection</h1>
            <table> 
            <tbody>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Quality</th>
                <th>Quantity</th>
              </tr>
              {cards}
            </tbody>
            </table>
            </>;

          setMain(collContent);
      });
    }
  }

  // Show the wishlist of the given user
  const showWish = () => {
    console.log("---showWish");
    // if not logged in, let them know its needed to see a wishlist
    if (!isLoggedin){
      const wishContent = 
        <>
        <h1>Wishlist</h1>
        <p> Please log in to view your wishlist. </p>
        </>;

        setMain(wishContent);
    } 
    // otherwise, grab their wishlist and display it as a list
    else{
      console.log("Showing wishlist for " + user);
      Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/getWishlist', 
        {userName: user}).then((response) => {
          console.log(response.data);
          const cards = response.data.map((card) =>
            <li>
              {card.cardCode}: {card.cardName}
              <button onClick={()=>{del2Wishlist(card)}}>Delete</button>
            </li> );
          const wishContent = 
            <>
            <h1>Wishlist</h1>
            <ul>{cards}</ul>
            </>
          setMain(wishContent);
      });
    }
  }

  // try to log the user in with the given info
  const tryLogin = () =>{
    if (userIn != null && passIn != null) {
      console.log(userIn);
      console.log(passIn);
      const uName = userIn;
      Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/login', 
        {userInput: userIn, passInput: passIn}).then((response) => {
          //console.log(response.data);
          // if the serve said it was good, log them in and route to home page (sets)
          if (response.data){
            setUser(uName);
            setLogged(true);
            showSets();
          }
          // else don't do anything, but inform it didn't work out
          else {
            console.log('Invalid Username or Password');
          }
      });
    }
  }


  // try to register a user
  const tryRegister = () =>{
      // make sure input is good
      if (userIn != null && passIn != null && userIn !=='' && passIn !== '') {
      console.log(userIn);
      console.log(passIn);
      const uName = userIn;
      // lets see what the server says
      Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/register', 
        {userInput: userIn, passInput: passIn}).then((response) => {
          //console.log(response.data);
          // if all's good, log them in with the new info
          if (response.data){
            setUser(uName);
            setLogged(true);
          }
          // if that username was taken, let them know
          else {
            console.log('Username already taken');
          }
      });
    }
  }

  // log the user out and bounce to main page (sets)
  const tryLogout = () =>{
    console.log("---tryLogout");
    setUser('');
    setLogged(false);
    setUserIn('');
    setPassIn('');
    showSets();
  } //----------------------------------------


  //Searches for sets and cards with given info, then displays all sets and cards that match
  const doSearch = () =>{
    console.log("---doSearch");
    if (searchIn != null && searchIn !== "") {
      console.log(searchIn);

      //Search for sets and cards that match the input
      Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/search', 
        {searchParam: searchIn}).then((response) => {
          console.log(response.data);
          const setResults = response.data[0];
          const cardResults = response.data[1];

          //Display as two lists
          const sets = setResults.map((set) =>
            <li onClick={()=>{showSetCards(set.code)}}>{set.setName}</li> );

          const cards = cardResults.map((card) =>
            <li onClick={()=>{showCardInfo(card)}}>{card.cardCode}: {card.cardName}</li> );

          const searchContent = 
            <>
            <h1>Sets</h1>
            <ul>{sets}</ul>
            <h1>Cards</h1>
            <ul>{cards}</ul>
            </>;

          setMain(searchContent);
        });
    }
  }

  // Adds a given card to the user's personal collection
  const add2Collection = (card) =>{
    console.log("-----add to coll: " + card.cardCode + " " + qualityIn + " " + quantityIn);

    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/add2Coll', 
      {user:user, code:card.cardCode, name:card.cardName, quality:qualityIn, quantity:quantityIn}).then((response) => {
        console.log('   added');
        console.log(response.data);
      });
  } 

  // Changes an entry in the personal collection, needs to know what was changed (quantity or quality)
  const changeColl = (value, form, card) =>{
    console.log("-----change coll: " + value + " " + form + " " + card.cardCode);

    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/change2Coll', 
      {user:user, code:card.cardCode, name:card.cardName, currQuality:card.quality, currQuantity:card.quantity, form:form, value:value}).then((response) => {
        console.log('   updated');
        console.log(response.data);
        // refresh display
        showSets();
        showColl();
      });
  }

  // Deletes an entry from the personal collection
  const del2Collection = (card) =>{
    console.log("-----del from coll: " + card.cardCode + " " + qualityIn + " " + quantityIn);

    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/del2Coll', 
      {user:user, code:card.cardCode, quality:card.quality}).then((response) => {
        console.log('   deleted');
        // refresh display
        showSets();
        showColl();
      });
  }


  // Adds a given card to the user's wishlist
  const add2Wishlist = (card) =>{
    console.log("-----add to wish: " + card.cardCode);

    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/add2Wish', 
      {user:user, code:card.cardCode, name:card.cardName}).then((response) => {
        // if it worked out
        if (response.data){
            console.log('added to wishlist')
          }
          // if card was already in wishlist
          else {
            console.log('Card already in Wishlist');
          }
      });
  }

  // Deletes card from wishlist
  const del2Wishlist = (card) =>{
    console.log("-----del from wish: " + card.cardCode);

    Axios.post('http://ec2-3-12-132-39.us-east-2.compute.amazonaws.com:3001/api/del2Wish', 
      {user:user, code:card.cardCode}).then((response) => {
        console.log('   deleted');
        // refresh display
        showSets();
        showWish();
      });
  }

  //---------------------------------------------------------------------------------------------
  // Primary Render
  //---------------------------------------------------------------------------------------------


  return (
    <div className="App">
      <div id="banner">
        <h1> Yu-Gi-Oh! Card Catalogue </h1>

        <div id='searchDiv'>
          <input type='text' name="searchIn" placeholder="ex: LOB, Blue-Eyes" onChange={(e) => {setSearchIn(e.target.value);}}/>
          <button onClick={()=>{doSearch()}}>Search</button>
        </div>

        {logRegContent}
      </div>

      <div id="navBar">
        <div className="navBut" onClick={()=>{showSets()}}> Sets </div>
        <div className="navBut" onClick={()=>{showColl()}}> Personal Collection </div>
        <div className="navBut" onClick={()=>{showWish()}}> Wishlist </div>
      </div>

      <div id="mainDisp">
        {mainContent}
      </div>

    </div>
  );
}

export default App;
