----------------------------------------------------
               Coding Samples 
----------------------------------------------------
Owner: Nikolas Burks
Email: nikolas.burks@gmail.com

----------------------------------------------------
1.  Chat Room
----------------------------------------------------
- This web-hosted project is a multi-room chat server
  that utilized Node.JS and Socket.IO.
- This was part of a school project, and as such, while
  touched upon, web security was not paramount.
- As this is not directly connected to a server, the
  databases used are not present and the program will
  not work "out of the box."


----------------------------------------------------
2.  Yu-Gi-Oh! Card Catalogue
----------------------------------------------------
- This web-hosted project served as a piece of card
  cataloging software to record which cards of a set
  were owned, conditions, amount, etc.
- This project utilized React and Express (Node.js),
  as well as Axios and Sequelize.
- This also served as a school project, where web
  security was not important
- Images of each card in the database were not fully
  imported, and many are left using the default image
- As this is not directly connected to a server, the
  databases used are not present and the program will
  not work "out of the box."