
// Setting up Node.JS and Socket.io-----------------------------------------------------------------------------
// Require the functionality we need to use:
var http = require('http'),
	url = require('url'),
	path = require('path'),
	mime = require('mime'),
	path = require('path'),
	fs = require('fs');

// Make a simple fileserver for all of our static content.
// Everything underneath static will be served.
var server = http.createServer(function(req, resp){
	var filename = path.join(__dirname, url.parse(req.url).pathname);
	(fs.exists || path.exists)(filename, function(exists){
		if (exists) {
			fs.readFile(filename, function(err, data){
				if (err) {
					// File exists but is not readable (permissions issue?)
					resp.writeHead(500, {
						"Content-Type": "text/plain"
					});
					resp.write("Internal server error: could not read file");
					resp.end();
					return;
				}
				
				// File exists and is readable
				var mimetype = mime.getType(filename);
				resp.writeHead(200, {
					"Content-Type": mimetype
				});
				resp.write(data);
				resp.end();
				return;
			});
		}else{
			// File does not exist
			resp.writeHead(404, {
				"Content-Type": "text/plain"
			});
			resp.write("Requested file not found: "+filename);
			resp.end();
			return;
		}
	});
});
server.listen(3456);


// Import Socket.IO and pass our HTTP server object to it.
const socketio = require("socket.io")(http, {
    wsEngine: 'ws'
});

// ------------------------------------------------------------------------------------
// Classes and non-socket functions
//-------------------------------------------------------------------------------------

//class for a Room object (chatroom)
class Room {
 	constructor(title, password, creator){
   	 	this.title = title;
   	 	this.password = password;
   	 	this.creator = creator;
   	 	this.activeUsers = {}; //empty dict for active users
   	 	this.bannedUsers = []; //empty array for banned users
 	}
}

// Just checks is a string has anything other than whitespace
//Taken from user Roko C. Buljan on https://stackoverflow.com/questions/3937513/javascript-validation-for-empty-input-field
function isEmpty(str) {
	return !String(str).trim().length;
}

//---------------------------------------------------------------------------------------

// global server variables
const room1 = new Room("Room 1", null, "root"); //couple of default rooms
const room2 = new Room("Room 2", null, "root");
const roomDict = {"Room 1": room1, "Room 2": room2}; // Dictionary for all chatrooms on the server
const userDict = {}; // Dictionary for all users in the server

//----------------------------------------------------------------------------------------
// Socket Functions
//----------------------------------------------------------------------------------------
// Attach our Socket.IO server to our HTTP server to listen
const io = socketio.listen(server);
io.sockets.on("connection", function (socket) {
    // This callback runs when a new Socket.IO connection is established.

    // Logs the user in
    socket.on('login_2serv', function (data) {
    	// if the username is blank, announce as invalid
        if (isEmpty(data["name"])){
        	console.log("Invalid Username");
        	socket.emit("announce_2client", "Invalid Username");
        }
        // if there is already a user with that name, say it's taken
        else if (Object.values(userDict).includes(data['name'])){
        	console.log("Username Taken");
        	socket.emit("announce_2client", "Username Has Already Been Taken");
        }
        // if alright, log them in
        else{
        	data["roomList"] = roomDict;
        	userDict[socket.id] = data['name']; //add to userDict
        	console.log("login: " + data["name"] + " " + data["picURL"]); //
        	//console.log("userDict: " + JSON.stringify(userDict));
        	socket.emit("login_2client", data); // login on client side
        }
    });


    // Creates a new chat room
    socket.on("createRoom_2serv", function (data) {
    	// if the room name is blank, announce as invalid
        if (isEmpty(data["roomName"])){
        	console.log("Invalid Room Name");
        	socket.emit("announce_2client", "Invalid Room Name");
        }
        // if there is already a room with that name
        else if (Object.keys(roomDict).includes(data['roomName'])){
        	console.log("Room Name Taken");
        	socket.emit("announce_2client", "Room Name Has Already Been Taken");
        }
        // if all's well, create the new room
        else{
        	// if the pass is empty, make it null
        	if (isEmpty(data["roomPass"])){
        		data["roomPass"] = null;
        	}
        	
        	const newRoom = new Room(data['roomName'], data['roomPass'], data['user']); 
        	roomDict[newRoom.title] = newRoom; // add new room to dict
        	console.log("New Room Created: " + data["roomName"] + " " + data["roomPass"] + " " + data['user']);
        	socket.emit("announce_2client", "New Room Created!"); // Announce to user
        	io.sockets.emit("reloadRooms_2client", roomDict); // reload the chat rooms list for all users
        }
    });

    // Checks if the passed password is correct for a room and puts user in room
    socket.on('checkRoomPass_2serv', function (data) {
    	// checks if the room pass is right (again, would usually be hashed)
    	const toRoom = roomDict[data['room'].title];
        if (data['inputPass'] != data['room'].password){
        	console.log("Incorrect Room Pass: " + data['inputPass'] + " " + data['room'].password);
        	socket.emit("announce_2client", "Incorrect Room Password"); // announce to user
        }
        // checks if the user is banned from the room
        else if (toRoom.bannedUsers.includes(userDict[socket.id])){
        	console.log("Banned: " + data['room'].title + " " + userDict[socket.id]);
        	socket.emit("announce_2client", "You Are Banned From This Room"); // announce to user
        }
		// if alright, change the room
        else{
			//console.log(data['currRoom']);
			// if coming from another room
        	if (data['currRoom'] != null){

        		// leave that socket room and remove from active users of previous room
        		socket.leave(data['currRoom'].title);
        		const fromRoom = roomDict[data['currRoom'].title];
        		console.log("Deleting user: " + userDict[socket.id]);
        		delete fromRoom.activeUsers[socket.id]; // delete the user to the rooms activeUsers dict

        		io.to(fromRoom.title).emit("reloadUsers_2client", fromRoom.activeUsers); // update active users for all in old socket room
        	}
        	socket.join(data['room'].title); // join the socket room for chat room
        	toRoom.activeUsers[socket.id] = userDict[socket.id]; // add the user to the rooms activeUsers dict

        	//console.log("Active Users: " + data['room'].title + " " + JSON.stringify(toRoom.activeUsers));
        	console.log("Changing to room: " + data["room"].title);
        	socket.emit("announce_2client", "Successfully Joined Room"); // announce to user
        	socket.emit("changeRoom_2client", toRoom); // change the client's room on the client side
        	io.to(data['room'].title).emit("reloadUsers_2client", toRoom.activeUsers); // update active users for all in new socket room
        }
    });


    // Sends a chat message, either private or general
    socket.on('sendMessage_2serv', function (data) {
    	
    	const msgString = String(data['message']);
		// if the message isn't empty,
        if (!isEmpty(msgString)){
        	//console.log("isEmpty: " + !isEmpty(msgString) + " " + msgString);

        	// if it's a private message
        	if (msgString.slice(0,13) == "<private> to "){
        		const toUser = msgString.split(':')[0].slice(13); // user is considered any text after the "...to " and before the first ':'
        		//console.log("toUser: " + toUser);

        		const chatRoom = roomDict[data['room'].title]; //get server side room object
        		//if the toUser exists in the room
        		if (Object.values(chatRoom.activeUsers).includes(toUser)){
        			socket.emit("announce_2client", ""); //clear announcment div
        			//post message to log of sender
        			socket.emit("postMessage_2client", data); //send out message to sender

        			//post message to log of receiver
        			const userID = Object.keys(chatRoom.activeUsers).find(key => chatRoom.activeUsers[key] === toUser); //get toUser's socket ID
        			const msg = msgString.split(/:(.*)/s)[1]; //get just the actual message
        			console.log("Private Msg from " + data['user'] + " to " + toUser + ": " + data['message']);
        			data['message'] = "<private> from " + data['user'] + ":" + msg; //format msg
        			io.to(userID).emit("postMessage_2client", data); //send out message to receiver
        		}
        		// if the toUser isn't in the room
        		else {
        			socket.emit("announce_2client", "User Not in Room"); //anounce to user
        		}
        	}
        	// if it's a general message 
        	else {
        		socket.emit("announce_2client", ""); //clear announcement div
	        	const msg = data['message'];
	        	data['message']	= data['user'] + ": " + msg; //update message to include user at front
	        	console.log("Msg from " + data['user'] + ": " + data['message']);
	        	io.to(data['room'].title).emit("postMessage_2client", data); //send message to all in socket room
        	}
        }
    });


    // Kicks a user from the chat room
    socket.on('kickUser_2serv', function(data){
    	// if the user name isn't blank
        if (!isEmpty(data["user"])){

        	const chatRoom = roomDict[data['room'].title]; // get the server side room obj
        	// if the user is in the room
        	if (Object.values(chatRoom.activeUsers).includes(data['user'])){
	        	console.log("Kicking User: " + data['user']);
	        	
	        	const userID = Object.keys(chatRoom.activeUsers).find(key => chatRoom.activeUsers[key] === data['user']); //get kicked users socket ID
	        	delete chatRoom.activeUsers[userID]; //remove user from activeUsers list
	        	io.to(chatRoom.title).emit("reloadUsers_2client", chatRoom.activeUsers); // update active users for all in old socket room
	        	io.to(userID).emit("throwToLobby_2client", roomDict); //thow them to the lobby
	        }
	        // if that user isn't in the room
        	else {
        		socket.emit("announce_2client", "No Such User In Room"); //anounce to user
        	}
        }	
    });


    // Bans a user from the chat room
    socket.on('banUser_2serv', function(data){
    	// if the user name isn't blank
        if (!isEmpty(data["user"])){

        	const chatRoom = roomDict[data['room'].title]; //get the server side room obj
        	// if the user is in the room, kick them
        	if (Object.values(chatRoom.activeUsers).includes(data['user'])){
	        	console.log("Kicking User: " + data['user']);
	        	
	        	const userID = Object.keys(chatRoom.activeUsers).find(key => chatRoom.activeUsers[key] === data['user']); //get banned users socket ID
	        	delete chatRoom.activeUsers[userID]; //remove user from activeUsers list
	        	io.to(chatRoom.title).emit("reloadUsers_2client", chatRoom.activeUsers); // update active users for all in old socket room
	        	io.to(userID).emit("throwToLobby_2client", roomDict); //thow them to the lobby
	        }
        	
        	// if the user exists, add them to the room's ban list
        	if (Object.values(userDict).includes(data['user'])){
        		console.log("Banning User: " + data['user']);
        		chatRoom.bannedUsers.push(data['user']);
        	}
        }	
    });

    // if I want... I don't think I need to worry about loggin out (per Piaza answers)
    //socket.on("disconnecting", function(){
    	//delete userDict[socket.id]; //delete user from userDict
    	// delete user from chat rooms activeUsers
    	// call reloadUsers_2client
    //});
});